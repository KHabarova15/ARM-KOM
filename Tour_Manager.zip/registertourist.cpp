#include "registertourist.h"
#include "ui_registertourist.h"
#include <QFile>

RegisterTourist::RegisterTourist(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::RegisterTourist)
{
    ui->setupUi(this);


}

RegisterTourist::~RegisterTourist()
{
    qDebug() << "in ~RegisterTourist()";
    delete ui;
}

void RegisterTourist::on_btnSave_clicked()
{


        QString FirstName = ui->txtxFirstName->text();
        QString MiddleName = ui->txtMiddleName->text();
        QString LastName = ui->txtLastName->text();
        QString PassportNo = ui->txtPassport->text();
        QString ContactNo = ui->txtContactNumber->text();
        QString PermanentAddress = ui->txtPermamentAdress->text();
        QString PackageName = ui->cmbChoosePackage->currentText();

        qDebug() << "First Name: " << FirstName << " Middle Name: " << MiddleName << " Last Name: " << LastName;
        qDebug() << "Passport Number: " << PassportNo << " Contact Number: " << ContactNo << " Permanent Address: " << PermanentAddress;
        qDebug() << "Package Name: " << PackageName;

        QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
        database.setDatabaseName("C:/Users/Aegon/Documents/ARM2.db");

        if (!database.open()) {
            qDebug() << "Error: " << database.lastError().text();
            return;
        } else {
            qDebug() << "Database opened successfully";


        QSqlQuery query(database);
        query.prepare("INSERT INTO Tourist (FirstName, MiddleName, LastName, PassportNo, ContactNo, PermanentAddress, PackageName) "
                      "VALUES (:firstName, :middleName, :lastName, :passportNo, :contactNo, :permanentAddress, :packageName)");
        query.bindValue(":firstName", FirstName);
        query.bindValue(":middleName", MiddleName);
        query.bindValue(":lastName", LastName);
        query.bindValue(":passportNo", PassportNo);
        query.bindValue(":contactNo", ContactNo);
        query.bindValue(":permanentAddress", PermanentAddress);
        query.bindValue(":packageName", PackageName);

        if (!query.exec()) {
            qDebug() << "Error executing query: " << query.lastError().text();
        } else {
            qDebug() << "Data inserted successfully";
        }

        database.close();
    }
}









void RegisterTourist::on_btnReset_clicked()
{
    ui->txtxFirstName->clear();
    ui->txtLastName->clear();
    ui->txtMiddleName->clear();
    ui->txtContactNumber->clear();
    ui->txtPassport->clear();
    ui->txtPermamentAdress->clear();
    ui->txtPackageDescription->clear();
}



void RegisterTourist::on_cmbChoosePackage_activated(int index)

{
    QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("C:/Users/Aegon/Documents/ARM2.db");

    if (!database.open()) {
        qDebug() << "Error: " << database.lastError().text();
        return;
    } else {
        qDebug() << "Database opened successfully";
    }
    QSqlQuery query;
    query.prepare("SELECT PackageName FROM Package");

    if (query.exec()) {
        while (query.next()) {
            ui->cmbChoosePackage->addItem(query.value(0).toString());
            qDebug() << "Заполнение Combobox:" << query.value(0).toString();
        }
    } else {
        qDebug() << "Ошибка при выполнении запроса:" << query.lastError().text();
    }
}




void RegisterTourist::on_loadPakcage_clicked()
{
    QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("C:/Users/Aegon/Documents/ARM2.db");

    if (!database.open()) {
        qDebug() << "Error: " << database.lastError().text();
        return;
    } else {
        qDebug() << "Database opened successfully";
    }


    QSqlQuery query(database);

    query.prepare("select PackageName from Package");
    query.exec();
    while(query.next())
    {
        ui->cmbChoosePackage->addItem(query.value(0).toString());
        qDebug() << "Filling Combobox " << query.value(0).toString();
    }

    qDebug() << "Last error : "<< query.lastQuery();
    qDebug() << "Last error : "<< query.lastError().text();
}

