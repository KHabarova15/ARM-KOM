#include "mainwindow.h"
#include "./ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ptraddpackage = new AddPackage();
    ptrfindpackage = new FindPackage();
    ptrfindtourist = new FindTourist();
    ptrregestertourist = new RegisterTourist();

}

MainWindow::~MainWindow()
{
    delete ptraddpackage;
    delete ptrfindpackage;
    delete ptrfindtourist;
    delete ptrregestertourist;
    delete ui;
}

void MainWindow::on_pushButton_2_clicked()
{
    ptraddpackage->show();
}


void MainWindow::on_pushButton_4_clicked()
{
    ptrregestertourist->show();
}


void MainWindow::on_pushButton_3_clicked()
{
    ptrfindpackage->show();
}


void MainWindow::on_pushButton_clicked()
{
    ptrfindtourist->show();
}


void MainWindow::on_calendarWidget_activated(const QDate &date)
{

}

