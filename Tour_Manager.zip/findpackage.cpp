#include "findpackage.h"
#include "ui_findpackage.h"


FindPackage::FindPackage(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::FindPackage)
{
    ui->setupUi(this);
}

FindPackage::~FindPackage()
{
    delete ui;
    delete model;
}

void FindPackage::on_btnFindPackage_clicked()
{
    QString packageName = ui->txtPackageName->text();
   /* QString packageDescription = ui->txtDescription->toPlainText();
    QString amount = ui->txtAmount->text();
    qDebug() << "Package Name : "<< packageName << "Package Description: " << packageDescription << "Amount: " << amount;*/
    QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("C:/Users/Aegon/Documents/ARM2.db");
    if(QFile::exists("C:/Users/Aegon/Documents/ARM2.db")){
        qDebug() <<"data base file exisist";
    }
    else{
        qDebug()<<"Database file not exist";
        return;
    }
    if (!database.open()){
        qDebug()<<"error";
        return;
    }
    else{
        qDebug()<<"Database open seccesfuly";

    }
    QSqlQuery query(database);
    query.prepare("select * from Package where PackageName like :packageName");
    query.bindValue(":packageName", "%" + packageName + "%");

    query.exec();
    qDebug() << "Last query: "<<query.lastQuery();
    qDebug()<<"Last error"<<query.lastError().text();
    if(model == NULL){
        model = new QSqlQueryModel();
    }
    model->setQuery(std::move(query));
    ui->tableView->setModel(model);
    ui->tableView->setColumnWidth(0,200);
    ui->tableView->setColumnWidth(1,200);
    ui->tableView->setColumnWidth(2,200);

    database.close();

}

