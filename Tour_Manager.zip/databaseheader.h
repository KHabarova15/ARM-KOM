#ifndef DATABASEHEADER_H
#define DATABASEHEADER_H
#include <QtSql>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlDriver>
#include <QtSql/QSqlError>
#include<QtSql/QsqlQuery>
#include <QDebug>
#include <QtSql/QSqlTableModel>
#include <QFile>
#include <QFile>
#endif // DATABASEHEADER_H
